<?php

$login = $_GET['login'];
$password=$_GET['password'];
$fileo="users/$login.txt";
if (file_exists($fileo)){
	$file= fopen("users/$login.txt", "r");
		while(!feof($file))
	{
    $str = htmlentities(fgets($file));
	}
	if ($str==md5($password)){
	 exit("Вход выполнен успешно");
 }
 else{
	 exit("Не верный пароль");
 }
		}
else
		{
		exit("Не зарегестрированный пользователь");
		}
fclose($file);
?>